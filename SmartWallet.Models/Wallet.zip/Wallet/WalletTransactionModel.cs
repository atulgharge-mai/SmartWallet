﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartWallet.Models.Wallet
{
    public class WalletTransactionModel
    {
        #region Private Fields
        private Guid _walletTransactionID;
        private Guid _orderID;
        private string _transactionNumber = "0";
        private string _trackingID = "111";
        private string _bankRefrenceNumber = "122";
        private string _failureMessage = "test";
        private string _paymentMode = "test";
        private string _description = "test";
        private string _amount = "test";
        private string _currency = "test";
        private string _walletID = "test";
        private string _transactionType = "test";
        private string _remark = "test";
        private int _status;
        private DateTime _transactionDate;
        private DateTime _createdDate;
        private DateTime _modifiedDate;
        private Guid _createdByID;
        private Guid _modifiedByID;
        #endregion

        #region Public Property
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid WalletTransactionID { get => _walletTransactionID; set => _walletTransactionID = value; }

        [ForeignKey("Order")]
        public Guid OrderID { get => _orderID; set => _orderID = value; }

        [MaxLength(128)]
        public string TransactionNumber { get => _transactionNumber; set => _transactionNumber = value; }

        [MaxLength(128)]
        public string TrackingID { get => _trackingID; set => _trackingID = value; }

        [MaxLength(128)]
        public string BankRefrenceNumber { get => _bankRefrenceNumber; set => _bankRefrenceNumber = value; }

        [MaxLength(128)]
        public string FailureMessage { get => _failureMessage; set => _failureMessage = value; }

        [MaxLength(128)]
        public string PaymentMode { get => _paymentMode; set => _paymentMode = value; }

        [MaxLength(128)]
        public string Description { get => _description; set => _description = value; }
        public string Amount { get => _amount; set => _amount = value; }

        [MaxLength(16)]
        public string Currency { get => _currency; set => _currency = value; }

        [ForeignKey("Wallet")]
        public string WalletID { get => _walletID; set => _walletID = value; }

        [MaxLength(16)]
        public string TransactionType { get => _transactionType; set => _transactionType = value; }

        [MaxLength(128)]
        public string Remark { get => _remark; set => _remark = value; }
        public int Status { get => _status; set => _status = value; }
        public DateTime TransactionDate { get => _transactionDate; set => _transactionDate = value; }
        public DateTime CreatedDate { get => _createdDate; set => _createdDate = value; }
        public DateTime ModifiedDate { get => _modifiedDate; set => _modifiedDate = value; }
        public Guid CreatedByID { get => _createdByID; set => _createdByID = value; }
        public Guid ModifiedByID { get => _modifiedByID; set => _modifiedByID = value; }
        #endregion
    }
}
